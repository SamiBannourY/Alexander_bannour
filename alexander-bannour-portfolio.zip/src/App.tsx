import { useState, useEffect, useRef, useMemo } from 'react';
import { motion, AnimatePresence, useScroll, useTransform, useSpring } from 'framer-motion';
import { freelancerData } from './data/portfolio';
import {
  useMousePosition,
  useScrollY,
  useIntersectionObserver,
  useAnimatedCounter,
  useTypingAnimation,
} from './hooks/useAnimations';

// Icons
const Icon = ({ name, className = '' }: { name: string; className?: string }) => {
  const icons: Record<string, JSX.Element> = {
    code: (
      <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <polyline points="16,18 22,12 16,6" /><polyline points="8,6 2,12 8,18" />
      </svg>
    ),
    cpu: (
      <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <rect x="4" y="4" width="16" height="16" rx="2" /><rect x="9" y="9" width="6" height="6" />
        <line x1="9" y1="1" x2="9" y2="4" /><line x1="15" y1="1" x2="15" y2="4" />
        <line x1="9" y1="20" x2="9" y2="23" /><line x1="15" y1="20" x2="15" y2="23" />
        <line x1="20" y1="9" x2="23" y2="9" /><line x1="20" y1="14" x2="23" y2="14" />
        <line x1="1" y1="9" x2="4" y2="9" /><line x1="1" y1="14" x2="4" y2="14" />
      </svg>
    ),
    palette: (
      <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <circle cx="13.5" cy="6.5" r="0.5" fill="currentColor" /><circle cx="17.5" cy="10.5" r="0.5" fill="currentColor" />
        <circle cx="8.5" cy="7.5" r="0.5" fill="currentColor" /><circle cx="6.5" cy="12.5" r="0.5" fill="currentColor" />
        <path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.926 0 1.648-.746 1.648-1.688 0-.437-.18-.835-.437-1.125-.29-.289-.438-.652-.438-1.125a1.64 1.64 0 0 1 1.668-1.668h1.996c3.051 0 5.555-2.503 5.555-5.555C21.965 6.012 17.461 2 12 2z" />
      </svg>
    ),
    smartphone: (
      <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <rect x="5" y="2" width="14" height="20" rx="2" ry="2" /><line x1="12" y1="18" x2="12.01" y2="18" />
      </svg>
    ),
    'shopping-cart': (
      <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <circle cx="9" cy="21" r="1" /><circle cx="20" cy="21" r="1" />
        <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6" />
      </svg>
    ),
    lightbulb: (
      <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <path d="M9 18h6M10 22h4M15.09 14c.18-.98.65-1.74 1.41-2.5A4.65 4.65 0 0 0 18 8 6 6 0 0 0 6 8c0 1 .23 2.23 1.5 3.5A4.61 4.61 0 0 1 8.91 14" />
      </svg>
    ),
    star: (
      <svg className={className} viewBox="0 0 24 24" fill="currentColor">
        <polygon points="12,2 15.09,8.26 22,9.27 17,14.14 18.18,21.02 12,17.77 5.82,21.02 7,14.14 2,9.27 8.91,8.26" />
      </svg>
    ),
    check: (
      <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <polyline points="20,6 9,17 4,12" />
      </svg>
    ),
    'chevron-down': (
      <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <polyline points="6,9 12,15 18,9" />
      </svg>
    ),
    menu: (
      <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <line x1="3" y1="12" x2="21" y2="12" /><line x1="3" y1="6" x2="21" y2="6" /><line x1="3" y1="18" x2="21" y2="18" />
      </svg>
    ),
    x: (
      <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" />
      </svg>
    ),
    mapPin: (
      <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" /><circle cx="12" cy="10" r="3" />
      </svg>
    ),
    mail: (
      <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" />
        <polyline points="22,6 12,13 2,6" />
      </svg>
    ),
    phone: (
      <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" />
      </svg>
    ),
    send: (
      <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <line x1="22" y1="2" x2="11" y2="13" /><polygon points="22,2 15,22 11,13 2,9" />
      </svg>
    ),
    calendar: (
      <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <rect x="3" y="4" width="18" height="18" rx="2" ry="2" /><line x1="16" y1="2" x2="16" y2="6" />
        <line x1="8" y1="2" x2="8" y2="6" /><line x1="3" y1="10" x2="21" y2="10" />
      </svg>
    ),
    github: (
      <svg className={className} viewBox="0 0 24 24" fill="currentColor">
        <path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z" />
      </svg>
    ),
    linkedin: (
      <svg className={className} viewBox="0 0 24 24" fill="currentColor">
        <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z" />
      </svg>
    ),
    twitter: (
      <svg className={className} viewBox="0 0 24 24" fill="currentColor">
        <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
      </svg>
    ),
    externalLink: (
      <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" />
        <polyline points="15,3 21,3 21,9" /><line x1="10" y1="14" x2="21" y2="3" />
      </svg>
    ),
    messageCircle: (
      <svg className={className} viewBox="0 0 24 24" fill="currentColor">
        <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z" />
      </svg>
    ),
    award: (
      <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <circle cx="12" cy="8" r="7" /><polyline points="8.21,13.89 7,23 12,20 17,23 15.79,13.88" />
      </svg>
    ),
    briefcase: (
      <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <rect x="2" y="7" width="20" height="14" rx="2" ry="2" /><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16" />
      </svg>
    ),
    graduationCap: (
      <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <path d="M22 10v6M2 10l10-5 10 5-10 5z" /><path d="M6 12v5c3 3 9 3 12 0v-5" />
      </svg>
    ),
    clock: (
      <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <circle cx="12" cy="12" r="10" /><polyline points="12,6 12,12 16,14" />
      </svg>
    ),
    zap: (
      <svg className={className} viewBox="0 0 24 24" fill="currentColor">
        <polygon points="13,2 3,14 12,14 11,22 21,10 12,10" />
      </svg>
    ),
    globe: (
      <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <circle cx="12" cy="12" r="10" /><line x1="2" y1="12" x2="22" y2="12" />
        <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z" />
      </svg>
    ),
    heart: (
      <svg className={className} viewBox="0 0 24 24" fill="currentColor">
        <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" />
      </svg>
    ),
    users: (
      <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
        <circle cx="9" cy="7" r="4" />
        <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
        <path d="M16 3.13a4 4 0 0 1 0 7.75" />
      </svg>
    ),
    dollarSign: (
      <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <line x1="12" y1="1" x2="12" y2="23" /><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6" />
      </svg>
    ),
  };
  return icons[name] || null;
};

// Cursor Glow Component
const CursorGlow = () => {
  const { x, y } = useMousePosition();
  const springOptions = { damping: 30, stiffness: 200 };

  return (
    <motion.div
      className="cursor-glow hidden md:block"
      animate={{ x, y }}
      transition={springOptions}
    />
  );
};

// Particle Background
const ParticleBackground = () => {
  const particles = useMemo(() =>
    Array.from({ length: 50 }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      y: Math.random() * 100,
      size: Math.random() * 4 + 1,
      duration: Math.random() * 20 + 10,
      delay: Math.random() * 5,
    })), []
  );

  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
      {particles.map((p) => (
        <motion.div
          key={p.id}
          className="particle"
          style={{ left: `${p.x}%`, top: `${p.y}%`, width: p.size, height: p.size }}
          animate={{
            y: [0, -30, 0],
            opacity: [0.2, 0.6, 0.2],
            scale: [1, 1.2, 1],
          }}
          transition={{ duration: p.duration, delay: p.delay, repeat: Infinity, ease: "easeInOut" }}
        />
      ))}
    </div>
  );
};

// Scroll Progress
const ScrollProgress = () => {
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, { stiffness: 100, damping: 30 });

  return <motion.div className="scroll-progress" style={{ scaleX, width: '100%' }} />;
};

// Navigation
const Navigation = () => {
  const [isOpen, setIsOpen] = useState(false);
  const scrollY = useScrollY();
  const isScrolled = scrollY > 50;

  const navLinks = ['About', 'Services', 'Portfolio', 'Testimonials', 'Skills', 'Contact'];

  const handleNavClick = (id: string) => {
    setIsOpen(false);
    const element = document.getElementById(id.toLowerCase());
    element?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <>
      <motion.nav
        className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
          isScrolled ? 'glass py-4' : 'py-6'
        }`}
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="container mx-auto px-6 flex items-center justify-between">
          <motion.a
            href="#"
            className="text-2xl font-bold font-display"
            whileHover={{ scale: 1.05 }}
          >
            <span className="bg-gradient-to-r from-purple-500 to-blue-500 bg-clip-text text-transparent">
              AS
            </span>
          </motion.a>

          <div className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <button key={link} onClick={() => handleNavClick(link)} className="nav-link text-sm font-medium">
                {link}
              </button>
            ))}
          </div>

          <div className="hidden md:flex items-center gap-4">
            <a
              href={freelancerData.fiverrUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="btn-premium text-sm"
            >
              <span>Hire Me</span>
            </a>
          </div>

          <button
            className="md:hidden p-2"
            onClick={() => setIsOpen(!isOpen)}
            aria-label="Toggle menu"
          >
            <Icon name={isOpen ? 'x' : 'menu'} className="w-6 h-6" />
          </button>
        </div>
      </motion.nav>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            className="mobile-menu flex flex-col items-center justify-center gap-8"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            {navLinks.map((link, i) => (
              <motion.button
                key={link}
                onClick={() => handleNavClick(link)}
                className="text-2xl font-display text-white"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
              >
                {link}
              </motion.button>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

// Hero Section
const Hero = () => {
  const { ref, isIntersecting } = useIntersectionObserver({ threshold: 0.3 });
  const roles = ['Full-Stack Developer', 'AI Engineer', 'UI/UX Designer', 'Digital Architect'];
  const typedText = useTypingAnimation(roles, 80, 40, 2000);

  return (
    <section ref={ref} className="min-h-screen relative flex items-center pt-20 overflow-hidden">
      <div className="hero-bg" />

      <div className="container mx-auto px-6 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div
            className="space-y-8"
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            <motion.div className="badge-premium w-fit" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.3 }}>
              <span className="availability" />
              {freelancerData.availability}
            </motion.div>

            <div className="space-y-4">
              <motion.p className="text-purple-400 font-medium" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.4 }}>
                Welcome to my portfolio
              </motion.p>
              <motion.h1 className="text-5xl md:text-7xl font-bold font-display leading-tight" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 }}>
                Hi, I'm{' '}
                <span className="bg-gradient-to-r from-purple-400 via-blue-500 to-cyan-400 bg-clip-text text-transparent">
                  {freelancerData.name}
                </span>
              </motion.h1>
              <div className="h-12 md:h-16">
                <span className="text-2xl md:text-4xl font-display text-white/80">
                  {typedText}
                  <span className="animate-blink text-purple-500">|</span>
                </span>
              </div>
            </div>

            <motion.p className="text-lg text-white/60 max-w-xl" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.6 }}>
              {freelancerData.tagline}. I transform complex challenges into elegant, scalable solutions that drive measurable results.
            </motion.p>

            <motion.div className="flex flex-wrap gap-4" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.7 }}>
              <a href={freelancerData.fiverrUrl} target="_blank" rel="noopener noreferrer" className="btn-premium">
                <span className="flex items-center gap-2">
                  <Icon name="briefcase" className="w-5 h-5" />
                  Hire Me on Fiverr
                </span>
              </a>
              <button onClick={() => document.getElementById('portfolio')?.scrollIntoView({ behavior: 'smooth' })} className="btn-outline">
                View Projects
              </button>
            </motion.div>

            <motion.div className="flex items-center gap-6 pt-4" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.8 }}>
              {[
                { icon: 'github', url: freelancerData.social.github },
                { icon: 'linkedin', url: freelancerData.social.linkedin },
                { icon: 'twitter', url: freelancerData.social.twitter },
              ].map((social) => (
                <a
                  key={social.icon}
                  href={social.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-3 rounded-xl glass-card hover:bg-white/10 transition-colors"
                >
                  <Icon name={social.icon} className="w-5 h-5" />
                </a>
              ))}
            </motion.div>
          </motion.div>

          <motion.div
            className="relative flex justify-center"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.3 }}
          >
            <div className="profile-frame relative">
              <div className="w-72 h-72 md:w-96 md:h-96 rounded-full overflow-hidden border-4 border-white/10">
                <img
                  src="/profile.png"
                  alt={freelancerData.name}
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Floating Elements */}
              <motion.div
                className="absolute -top-4 -right-4 p-4 glass-card rounded-2xl"
                animate={{ y: [0, -10, 0] }}
                transition={{ duration: 3, repeat: Infinity }}
              >
                <Icon name="zap" className="w-8 h-8 text-amber-400" />
              </motion.div>
              <motion.div
                className="absolute -bottom-4 -left-4 p-4 glass-card rounded-2xl"
                animate={{ y: [0, 10, 0] }}
                transition={{ duration: 4, repeat: Infinity }}
              >
                <Icon name="award" className="w-8 h-8 text-purple-400" />
              </motion.div>
              <motion.div
                className="absolute top-1/2 -right-8 p-3 glass-card rounded-xl"
                animate={{ x: [0, 5, 0] }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                <Icon name="star" className="w-6 h-6 text-amber-400" />
              </motion.div>
            </div>
          </motion.div>
        </div>
      </div>

      <motion.div
        className="absolute bottom-10 left-1/2 transform -translate-x-1/2"
        animate={{ y: [0, 10, 0] }}
        transition={{ duration: 2, repeat: Infinity }}
      >
        <Icon name="chevron-down" className="w-8 h-8 text-white/50" />
      </motion.div>
    </section>
  );
};

// Stats Section
const Stats = () => {
  const { ref, isIntersecting } = useIntersectionObserver({ threshold: 0.3 });

  return (
    <section ref={ref} className="py-20 relative">
      <div className="container mx-auto px-6">
        <div className="glass-card rounded-3xl p-8 md:p-12">
          <div className="grid grid-cols-2 md:grid-cols-5 gap-8">
            {freelancerData.stats.map((stat, i) => (
              <motion.div
                key={stat.label}
                className="text-center"
                initial={{ opacity: 0, y: 30 }}
                animate={isIntersecting ? { opacity: 1, y: 0 } : {}}
                transition={{ delay: i * 0.1, duration: 0.5 }}
              >
                <AnimatedCounter
                  value={stat.value}
                  suffix={stat.suffix}
                  prefix={stat.prefix}
                  shouldStart={isIntersecting}
                />
                <p className="text-white/60 mt-2 text-sm md:text-base">{stat.label}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

const AnimatedCounter = ({ value, suffix = '', prefix = '', shouldStart = false }: { value: number; suffix?: string; prefix?: string; shouldStart?: boolean }) => {
  const count = useAnimatedCounter(value, 2000, 0, shouldStart);

  const displayValue = value % 1 !== 0 ? (count / 10).toFixed(1) : count;

  return (
    <div className="stat-number">
      {prefix}{displayValue}{suffix}
    </div>
  );
};

// Services Section
const Services = () => {
  const [activeService, setActiveService] = useState<string | null>(null);
  const { ref, isIntersecting } = useIntersectionObserver({ threshold: 0.2 });

  return (
    <section id="services" ref={ref} className="py-24 relative">
      <div className="ambient-glow w-96 h-96 -top-20 -left-20" />

      <div className="container mx-auto px-6">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          animate={isIntersecting ? { opacity: 1, y: 0 } : {}}
        >
          <h2 className="section-title">Premium Services</h2>
          <p className="section-subtitle">
            Comprehensive digital solutions tailored to elevate your business
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {freelancerData.services.map((service, i) => (
            <motion.div
              key={service.id}
              className="service-card glass-card rounded-2xl p-8 relative"
              initial={{ opacity: 0, y: 50 }}
              animate={isIntersecting ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: i * 0.1 }}
              onMouseEnter={() => setActiveService(service.id)}
              onMouseLeave={() => setActiveService(null)}
            >
              <div className="absolute top-6 right-6 pricing-badge">
                ${service.price}
              </div>

              <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-purple-500/20 to-blue-500/20 flex items-center justify-center mb-6">
                <Icon name={service.icon} className="w-7 h-7 text-purple-400" />
              </div>

              <h3 className="text-xl font-bold mb-3">{service.title}</h3>
              <p className="text-white/60 text-sm mb-6">{service.description}</p>

              <div className="space-y-2">
                {service.features.map((feature) => (
                  <div key={feature} className="flex items-center gap-2 text-sm text-white/70">
                    <Icon name="check" className="w-4 h-4 text-cyan-400" />
                    {feature}
                  </div>
                ))}
              </div>

              <motion.button
                className="mt-6 w-full py-3 rounded-xl border border-purple-500/50 text-purple-400 font-medium hover:bg-purple-500/10 transition-colors"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                Learn More
              </motion.button>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

// Portfolio Section
const Portfolio = () => {
  const [filter, setFilter] = useState('All');
  const [selectedProject, setSelectedProject] = useState<typeof freelancerData.portfolio[0] | null>(null);
  const { ref, isIntersecting } = useIntersectionObserver({ threshold: 0.2 });

  const categories = ['All', ...new Set(freelancerData.portfolio.map((p) => p.category))];
  const filteredProjects = filter === 'All' ? freelancerData.portfolio : freelancerData.portfolio.filter((p) => p.category === filter);

  return (
    <section id="portfolio" ref={ref} className="py-24 relative">
      <div className="ambient-glow w-96 h-96 -top-20 -right-20" />

      <div className="container mx-auto px-6">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          animate={isIntersecting ? { opacity: 1, y: 0 } : {}}
        >
          <h2 className="section-title">Featured Work</h2>
          <p className="section-subtitle">
            A selection of projects showcasing technical excellence and measurable results
          </p>
        </motion.div>

        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setFilter(cat)}
              className={`filter-btn ${filter === cat ? 'active' : ''}`}
            >
              {cat}
            </button>
          ))}
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProjects.map((project, i) => (
            <motion.div
              key={project.id}
              className="portfolio-card aspect-[4/3] cursor-pointer"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={isIntersecting ? { opacity: 1, scale: 1 } : {}}
              transition={{ delay: i * 0.1 }}
              onClick={() => setSelectedProject(project)}
              whileHover={{ y: -10 }}
            >
              <img src={project.image} alt={project.title} className="w-full h-full object-cover" />
              <div className="portfolio-card-content">
                <span className="badge-premium text-xs mb-2 w-fit">{project.category}</span>
                <h3 className="text-xl font-bold text-white mb-2">{project.title}</h3>
                <p className="text-white/80 text-sm mb-4">{project.description}</p>
                <div className="flex flex-wrap gap-2">
                  {project.results.slice(0, 2).map((result) => (
                    <span key={result} className="text-xs bg-white/20 px-2 py-1 rounded-full text-white">
                      {result}
                    </span>
                  ))}
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      <AnimatePresence>
        {selectedProject && (
          <motion.div
            className="modal-overlay flex items-center justify-center p-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setSelectedProject(null)}
          >
            <motion.div
              className="glass-card rounded-3xl max-w-4xl w-full max-h-[90vh] overflow-y-auto p-8"
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex justify-between items-start mb-6">
                <div>
                  <span className="badge-premium text-xs mb-2 w-fit">{selectedProject.category}</span>
                  <h3 className="text-3xl font-bold">{selectedProject.title}</h3>
                  <p className="text-white/60 mt-1">{selectedProject.client} - {selectedProject.year}</p>
                </div>
                <button onClick={() => setSelectedProject(null)} className="p-2 hover:bg-white/10 rounded-lg">
                  <Icon name="x" className="w-6 h-6" />
                </button>
              </div>
              <img src={selectedProject.image} alt={selectedProject.title} className="w-full h-64 object-cover rounded-2xl mb-6" />
              <p className="text-lg text-white/80 mb-6">{selectedProject.description}</p>
              <div className="grid grid-cols-3 gap-4">
                {selectedProject.results.map((result) => (
                  <div key={result} className="glass-card p-4 rounded-xl text-center">
                    <p className="text-2xl font-bold text-purple-400">{result}</p>
                  </div>
                ))}
              </div>
              <div className="flex gap-4 mt-8">
                <a href={freelancerData.fiverrUrl} target="_blank" rel="noopener noreferrer" className="btn-premium flex-1 text-center">
                  <span>Start Similar Project</span>
                </a>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
};

// Testimonials Section
const Testimonials = () => {
  const [activeIndex, setActiveIndex] = useState(0);
  const { ref, isIntersecting } = useIntersectionObserver({ threshold: 0.2 });

  useEffect(() => {
    if (!isIntersecting) return;
    const interval = setInterval(() => {
      setActiveIndex((prev) => (prev + 1) % freelancerData.testimonials.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [isIntersecting]);

  return (
    <section id="testimonials" ref={ref} className="py-24 relative overflow-hidden">
      <div className="ambient-glow w-96 h-96 top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />

      <div className="container mx-auto px-6">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          animate={isIntersecting ? { opacity: 1, y: 0 } : {}}
        >
          <h2 className="section-title">Client Testimonials</h2>
          <p className="section-subtitle">
            What industry leaders say about working together
          </p>
        </motion.div>

        <div className="max-w-4xl mx-auto">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeIndex}
              className="testimonial-card"
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -50 }}
              transition={{ duration: 0.5 }}
            >
              <div className="flex items-center gap-4 mb-6">
                <img
                  src={freelancerData.testimonials[activeIndex].avatar}
                  alt={freelancerData.testimonials[activeIndex].name}
                  className="w-16 h-16 rounded-full object-cover border-2 border-purple-500"
                />
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="font-bold text-lg">{freelancerData.testimonials[activeIndex].name}</h4>
                    {freelancerData.testimonials[activeIndex].verified && (
                      <span className="verified-badge">
                        <Icon name="check" className="w-3 h-3 text-white" />
                      </span>
                    )}
                  </div>
                  <p className="text-white/60 text-sm">{freelancerData.testimonials[activeIndex].role}</p>
                </div>
                <div className="ml-auto flex gap-1">
                  {[...Array(5)].map((_, i) => (
                    <Icon
                      key={i}
                      name="star"
                      className={`w-5 h-5 ${i < freelancerData.testimonials[activeIndex].rating ? 'star-filled' : 'text-white/20'}`}
                    />
                  ))}
                </div>
              </div>
              <p className="text-lg text-white/80 leading-relaxed">
                "{freelancerData.testimonials[activeIndex].content}"
              </p>
            </motion.div>
          </AnimatePresence>

          <div className="flex justify-center gap-2 mt-8">
            {freelancerData.testimonials.map((_, i) => (
              <button
                key={i}
                onClick={() => setActiveIndex(i)}
                className={`w-3 h-3 rounded-full transition-all ${
                  i === activeIndex ? 'bg-purple-500 w-8' : 'bg-white/20 hover:bg-white/40'
                }`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

// Timeline Section
const Timeline = () => {
  const { ref, isIntersecting } = useIntersectionObserver({ threshold: 0.2 });

  return (
    <section id="about" ref={ref} className="py-24 relative">
      <div className="container mx-auto px-6">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          animate={isIntersecting ? { opacity: 1, y: 0 } : {}}
        >
          <h2 className="section-title">Journey</h2>
          <p className="section-subtitle">
            A track record of growth, expertise, and impactful contributions
          </p>
        </motion.div>

        <div className="max-w-3xl mx-auto">
          {freelancerData.timeline.map((item, i) => (
            <motion.div
              key={item.year}
              className="timeline-item"
              initial={{ opacity: 0, x: -30 }}
              animate={isIntersecting ? { opacity: 1, x: 0 } : {}}
              transition={{ delay: i * 0.15 }}
            >
              <div className="glass-card rounded-2xl p-6 ml-4">
                <div className="flex items-center gap-4 mb-3">
                  <span className="text-sm font-bold text-purple-400 bg-purple-500/10 px-3 py-1 rounded-full">
                    {item.year}
                  </span>
                  <span className="text-xs text-white/50">{item.company}</span>
                </div>
                <h4 className="text-xl font-bold mb-2">{item.title}</h4>
                <p className="text-white/60 text-sm">{item.description}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

// Skills Section
const Skills = () => {
  const { ref, isIntersecting } = useIntersectionObserver({ threshold: 0.2 });

  return (
    <section id="skills" ref={ref} className="py-24 relative">
      <div className="ambient-glow w-96 h-96 -bottom-20 -left-20" />

      <div className="container mx-auto px-6">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          animate={isIntersecting ? { opacity: 1, y: 0 } : {}}
        >
          <h2 className="section-title">Expertise</h2>
          <p className="section-subtitle">
            Core technologies and skills that power exceptional results
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12">
          <div className="space-y-8">
            <h3 className="text-2xl font-bold mb-6">Technical Skills</h3>
            {freelancerData.skills.map((skill, i) => (
              <motion.div
                key={skill.name}
                initial={{ opacity: 0, x: -30 }}
                animate={isIntersecting ? { opacity: 1, x: 0 } : {}}
                transition={{ delay: i * 0.1 }}
              >
                <div className="flex justify-between mb-2">
                  <span className="font-medium">{skill.name}</span>
                  <span className="text-purple-400">{skill.level}%</span>
                </div>
                <div className="skill-bar">
                  <motion.div
                    className="skill-bar-fill"
                    initial={{ width: 0 }}
                    animate={isIntersecting ? { width: `${skill.level}%` } : {}}
                    transition={{ delay: i * 0.1 + 0.3, duration: 1, ease: "easeOut" }}
                  />
                </div>
              </motion.div>
            ))}
          </div>

          <div>
            <h3 className="text-2xl font-bold mb-6">Tools & Technologies</h3>
            <div className="flex flex-wrap gap-3">
              {freelancerData.tools.map((tool, i) => (
                <motion.span
                  key={tool}
                  className="px-4 py-2 rounded-full glass-card text-sm font-medium hover:bg-purple-500/20 transition-colors cursor-default"
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={isIntersecting ? { opacity: 1, scale: 1 } : {}}
                  transition={{ delay: i * 0.03 }}
                  whileHover={{ y: -2 }}
                >
                  {tool}
                </motion.span>
              ))}
            </div>

            <div className="mt-12 grid grid-cols-2 gap-4">
              {[
                { icon: 'users', label: '500+ Happy Clients', value: '98%' },
                { icon: 'clock', label: 'On-Time Delivery', value: '100%' },
                { icon: 'heart', label: 'Client Retention', value: '95%' },
                { icon: 'globe', label: 'Global Reach', value: '32+' },
              ].map((stat) => (
                <motion.div
                  key={stat.label}
                  className="glass-card rounded-xl p-4 text-center"
                  initial={{ opacity: 0, y: 20 }}
                  animate={isIntersecting ? { opacity: 1, y: 0 } : {}}
                  transition={{ delay: 0.5 }}
                >
                  <Icon name={stat.icon} className="w-6 h-6 text-purple-400 mx-auto mb-2" />
                  <p className="text-2xl font-bold text-white">{stat.value}</p>
                  <p className="text-xs text-white/60">{stat.label}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

// Contact Section
const Contact = () => {
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { ref, isIntersecting } = useIntersectionObserver({ threshold: 0.2 });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    await new Promise((resolve) => setTimeout(resolve, 2000));
    setIsSubmitting(false);
    setFormData({ name: '', email: '', message: '' });
  };

  return (
    <section id="contact" ref={ref} className="py-24 relative">
      <div className="ambient-glow w-96 h-96 top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />

      <div className="container mx-auto px-6">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          animate={isIntersecting ? { opacity: 1, y: 0 } : {}}
        >
          <h2 className="section-title">Let's Work Together</h2>
          <p className="section-subtitle">
            Ready to transform your vision into reality? Let's discuss your project.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12 max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={isIntersecting ? { opacity: 1, x: 0 } : {}}
            transition={{ delay: 0.2 }}
          >
            <h3 className="text-2xl font-bold mb-8">Get in Touch</h3>

            <div className="space-y-6 mb-12">
              <a href={`mailto:${freelancerData.email}`} className="flex items-center gap-4 p-4 glass-card rounded-xl group">
                <div className="w-12 h-12 rounded-xl bg-purple-500/20 flex items-center justify-center">
                  <Icon name="mail" className="w-6 h-6 text-purple-400" />
                </div>
                <div>
                  <p className="text-white/60 text-sm">Email</p>
                  <p className="font-medium group-hover:text-purple-400 transition-colors">{freelancerData.email}</p>
                </div>
              </a>

              <a href={`https://wa.me/${freelancerData.whatsapp}`} target="_blank" rel="noopener noreferrer" className="flex items-center gap-4 p-4 glass-card rounded-xl group">
                <div className="w-12 h-12 rounded-xl bg-green-500/20 flex items-center justify-center">
                  <Icon name="messageCircle" className="w-6 h-6 text-green-400" />
                </div>
                <div>
                  <p className="text-white/60 text-sm">WhatsApp</p>
                  <p className="font-medium group-hover:text-green-400 transition-colors">Chat Now</p>
                </div>
              </a>

              <div className="flex items-center gap-4 p-4 glass-card rounded-xl">
                <div className="w-12 h-12 rounded-xl bg-blue-500/20 flex items-center justify-center">
                  <Icon name="mapPin" className="w-6 h-6 text-blue-400" />
                </div>
                <div>
                  <p className="text-white/60 text-sm">Location</p>
                  <p className="font-medium">{freelancerData.location}</p>
                </div>
              </div>
            </div>

            <div className="glass-card rounded-2xl p-6">
              <h4 className="font-bold mb-4">Quick Booking</h4>
              <p className="text-white/60 text-sm mb-4">Schedule a free consultation call to discuss your project.</p>
              <a
                href={freelancerData.fiverrUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="btn-premium w-full text-center flex items-center justify-center gap-2"
              >
                <Icon name="calendar" className="w-5 h-5" />
                <span>Book on Fiverr</span>
              </a>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={isIntersecting ? { opacity: 1, x: 0 } : {}}
            transition={{ delay: 0.4 }}
          >
            <form onSubmit={handleSubmit} className="glass-card rounded-2xl p-8 space-y-6">
              <div>
                <label className="block text-sm font-medium mb-2">Your Name</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="input-premium"
                  placeholder="John Smith"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Email Address</label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="input-premium"
                  placeholder="john@company.com"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Your Message</label>
                <textarea
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  className="input-premium min-h-[150px] resize-none"
                  placeholder="Tell me about your project..."
                  required
                />
              </div>
              <button
                type="submit"
                disabled={isSubmitting}
                className="btn-premium w-full flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {isSubmitting ? (
                  <>
                    <motion.div
                      className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full"
                      animate={{ rotate: 360 }}
                      transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                    />
                    <span>Sending...</span>
                  </>
                ) : (
                  <>
                    <Icon name="send" className="w-5 h-5" />
                    <span>Send Message</span>
                  </>
                )}
              </button>
            </form>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

// Footer
const Footer = () => {
  return (
    <footer className="py-12 border-t border-white/10">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <span className="text-2xl font-bold font-display">
              <span className="bg-gradient-to-r from-purple-500 to-blue-500 bg-clip-text text-transparent">AS</span>
            </span>
            <span className="text-white/40">|</span>
            <span className="text-white/60 text-sm">{freelancerData.name}</span>
          </div>

          <div className="flex items-center gap-6">
            {[
              { icon: 'github', url: freelancerData.social.github },
              { icon: 'linkedin', url: freelancerData.social.linkedin },
              { icon: 'twitter', url: freelancerData.social.twitter },
            ].map((social) => (
              <a
                key={social.icon}
                href={social.url}
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 text-white/60 hover:text-white transition-colors"
              >
                <Icon name={social.icon} className="w-5 h-5" />
              </a>
            ))}
          </div>

          <a
            href={freelancerData.fiverrUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="px-6 py-3 rounded-xl bg-gradient-to-r from-purple-500 to-blue-500 font-semibold text-sm hover:opacity-90 transition-opacity flex items-center gap-2"
          >
            <Icon name="externalLink" className="w-4 h-4" />
            Hire Me on Fiverr
          </a>
        </div>

        <div className="mt-8 pt-8 border-t border-white/5 text-center">
          <p className="text-white/40 text-sm">
            © {new Date().getFullYear()} {freelancerData.name}. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

// Main App
function App() {
  return (
    <div className="relative">
      <CursorGlow />
      <ParticleBackground />
      <ScrollProgress />
      <Navigation />
      <main>
        <Hero />
        <Stats />
        <Services />
        <Portfolio />
        <Testimonials />
        <Timeline />
        <Skills />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}

export default App;
